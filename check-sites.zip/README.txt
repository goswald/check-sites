TO USE:

Edit the file "mysites.txt" and enter, one per line, a list of web addresses for sites you log into.
For instance, if you have accounts with discordapp.com, amazon.com, and google.com, you'd list them in the file like this:

amazon.com
discordapp.com
google.com

Save the file.
Mac and *nix users:  Set "check-sites.sh" as executable and run it.
Windows users: Double click to run "check-sites.exe."
Once the script completes, a list of sites will be put in "compromised_sites.txt."  
These are the sites you specified that match sites impacted by the "CloudBleed" bug.

Please feel free to look at the code in my script or contact me if you have any concerns. <3